package com.wazrix.model;



public class Api {
    public String getAPI() {
		return API;
	}
	public void setAPI(String aPI) {
		API = aPI;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public String getAuth() {
		return Auth;
	}
	public void setAuth(String auth) {
		Auth = auth;
	}
	public String getHTTPS() {
		return HTTPS;
	}
	public void setHTTPS(String hTTPS) {
		HTTPS = hTTPS;
	}
	public String getCors() {
		return Cors;
	}
	public void setCors(String cors) {
		Cors = cors;
	}
	public String getLink() {
		return Link;
	}
	public void setLink(String link) {
		Link = link;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public String API;
    public String Description;
    public String Auth;
    public String HTTPS;
    public String Cors;
    public String Link;
    public String Category;
}