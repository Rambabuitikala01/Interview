import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wazrix.model.Stock;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class WazrixTest {

    private ObjectMapper objectMapper = new ObjectMapper();
    private RequestSpecification requestSpecification;
    private final String uri = "https://api.wazirx.com/sapi/v1/tickers/24hr";

    Stock[] stocks = null;

    @BeforeTest
    public void setUp() throws IOException {
        requestSpecification = RestAssured.given();
        requestSpecification.accept(ContentType.JSON);
        Response response = requestSpecification.get(uri);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        stocks = objectMapper.readValue(response.getBody().asByteArray(), Stock[].class);
    }

    @Test
    public void getAllSymbolsWhoseOpenPriceIsLessThanLowPrice() throws IOException {

        List<String> symbolsList = new ArrayList<String>();
        for(Stock stock: stocks){
            double openPrice = Double.parseDouble(stock.getOpenPrice());
            double lowPrice = Double.parseDouble(stock.getLowPrice());

            if(openPrice < lowPrice){
                symbolsList.add(stock.getSymbol());
            }
        }

        System.out.println(symbolsList.size());
    }

    @Test
    public void getAllSuchSymbolsAndBaseAssetsWhoseVolumeAreMoreThanAverage() throws IOException {

        double volumes = 0;
        for(Stock stock: stocks){
            volumes = volumes + Double.parseDouble(stock.getVolume());
        }

        double volAvg = volumes/stocks.length;
        List<Stock> stocksList = new ArrayList<Stock>();

        for(Stock stock: stocks){
            double volume = Double.parseDouble(stock.getVolume());

            if(volume > volAvg){
                stocksList.add(stock);
            }
        }
        System.out.println(stocksList.size());
    }

    @Test
    public void diffBetweenBadAndAskPrice(){
        int count = 0;
        ArrayList<Stock> stocklist = new ArrayList<Stock>(Arrays.asList(stocks));
        Collections.sort(stocklist, new Comparator<Stock>() {
            public int compare(Stock o1, Stock o2) {
                double diff1 = Math.abs(Double.parseDouble(o1.getAskPrice()) - Double.parseDouble(o1.getBidPrice()));
                double diff2 = Math.abs(Double.parseDouble(o2.getAskPrice()) - Double.parseDouble(o2.getBidPrice()));
                if(diff1 < diff2){
                    return -1;
                }else
                    return 1;
            }
        });

       Iterator<Stock> iterator = stocklist.iterator();
        for (int i = 0; i < 5 && iterator.hasNext(); i++)
            System.out.println(iterator.next());

        }

}
