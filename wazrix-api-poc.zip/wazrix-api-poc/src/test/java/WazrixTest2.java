import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wazrix.model.Api;
import com.wazrix.model.Stock;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WazrixTest2 {

    private ObjectMapper objectMapper = new ObjectMapper();
    private RequestSpecification requestSpecification;
    private final String uri = "https://api.publicapis.org/entries";

    Stock[] stocks = null;
    List<Api> apis = new ArrayList<Api>();

    @BeforeTest
    public void setUp() throws IOException {
        requestSpecification = RestAssured.given();
        requestSpecification.accept(ContentType.JSON);
        Response response = requestSpecification.get(uri);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        Map<String, Object> data = objectMapper.readValue(response.getBody().asByteArray(), Map.class);
        List<Map<String, String>> apiData = (List<Map<String, String>>) data.get("entries");
        for(Map m : apiData){
            apis.add(objectMapper.convertValue(m, Api.class));
        }
    }

    @Test
    public void filterByCatagoryAndlink() {
        for (Api api : apis) {
            if(api.getCategory().equals("Animals")
            && api.getLink().contains("github"))
            System.out.println(api);
        }
    }

    @Test
    public void filterByCatagoryAndlinkCount() {
        int count = 0;
        for (Api api : apis) {
            if(api.getCategory().equals("Animals")
                    && api.getLink().contains("github"))
                count++;
        }

        System.out.println(count);
    }
}
